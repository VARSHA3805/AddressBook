#include <stdio.h>
#include "file.h"
#include "contact.h"
//Function defnition for save contacts to file
void saveContactsToFile(AddressBook *addressBook) 
{
    FILE *fp;
    //Open new file to save the contact, 'w' : represents write to file
    fp = fopen("add.csv","w");
    fprintf(fp,"%d\n",addressBook -> contactCount);
    for(int i = 0; i < addressBook -> contactCount ; i++)
    {
      //',' comma reperesent to get comma between the name,phone & email in file
      fprintf(fp,"%s,", addressBook -> contacts[i].name);
      fprintf(fp,"%s,", addressBook -> contacts[i].phone);
      fprintf(fp,"%s\n", addressBook -> contacts[i].email);
    } 
    fclose(fp);
}
//Function defnition for load contacts to new file
void loadContactsFromFile(AddressBook *addressBook) 
{
  
    FILE *fp;
    //Open new file to load the contact,'r': represents read from file
    fp = fopen("add.csv","r");
    fscanf(fp,"%d\n",&addressBook -> contactCount);
    for(int i = 0; i < addressBook -> contactCount ; i++)
    {
      //Here %[^,] : represent to print upto comma 
      fscanf(fp,"%[^,],", addressBook -> contacts[i].name);
      fscanf(fp,"%[^,],", addressBook -> contacts[i].phone);
      fscanf(fp,"%[^\n]\n", addressBook -> contacts[i].email);
    }
    fclose(fp);
  
}
