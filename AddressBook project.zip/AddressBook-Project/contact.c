#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
#include "populate.h"



//Function declarartion of listing the contacts
void listContacts(AddressBook *addressBook) 
{
         int i ;
         // Sort contacts based on the chosen criteria
         //print the list as table
         printf("\nNAME\t\tPHONE\t\tEMAIL\n\n");
         //Condition for listing inside the addressbook.
         for(i = 0; i < addressBook -> contactCount; i++)
         {


            //Print the information
            printf("%s\t",addressBook -> contacts[i].name);
            //Condition for if the string length is lessthen 8
            if(strlen(addressBook -> contacts[i].name) < 8)
            {
                printf("\t");
            }
            printf("%s\t",addressBook -> contacts[i].phone);
        
            printf("%s\t\n",addressBook -> contacts[i].email);
         }
  
    
}
//Function defnition for initilize the contacts
void initialize(AddressBook *addressBook) 
{
    addressBook->contactCount = 0;
    populateAddressBook(addressBook);
    
    // Load contacts from file during initialization (After files)
    //loadContactsFromFile(addressBook);
}
//Function defnition for save the contacts
void saveAndExit(AddressBook *addressBook) 
{
    //Function call
    saveContactsToFile(addressBook); // Save contacts to file
    exit(EXIT_SUCCESS); // Exit the program
}
//Function defnition for search the contact
void contactSearch1(char *cont , AddressBook *addressBook, int *flag , int *i_value)
{

    //Declaring the variables
    int i , num = 0;
    for(i = 0; i < addressBook -> contactCount ; i++)
    {
        //Case comparison for the name,phone and email
        if(strcasecmp(cont , addressBook -> contacts[i].name) == 0)
        {
            printf("\n\n");
            printf("Name = %s\n",addressBook -> contacts[i].name);
            printf("Phone = %s\n",addressBook -> contacts[i].phone);
            printf("Email = %s\n",addressBook -> contacts[i].email);
            num++;
            *i_value = i;
        }
    }
   *flag = num;
}
void contactSearch2(char *cont , AddressBook *addressBook, int *flag , int *i_value)
{

    //Declaring the variables
    int i , num = 0;
    for(i = 0; i < addressBook -> contactCount ; i++)
    {
        if(strcasecmp(cont , addressBook -> contacts[i].phone) == 0)
         { 
            printf("\n\n");
            printf("Name = %s\n",addressBook -> contacts[i].name);
            printf("Phone = %s\n",addressBook -> contacts[i].phone);
            printf("Email = %s\n",addressBook -> contacts[i].email);
            num++;
            *i_value = i;
        }
    }
   *flag = num;
}
//Function defnition 
void contactSearch3(char *cont , AddressBook *addressBook, int *flag , int *i_value)
{

    //Declaring the variables
    int i , num = 0;
    for(i = 0; i < addressBook -> contactCount ; i++)
    {
        if(strcasecmp(cont , addressBook -> contacts[i].email) == 0)
        {
            printf("\n\n");
            printf("Name = %s\n",addressBook -> contacts[i].name);
            printf("Phone = %s\n",addressBook -> contacts[i].phone);
            printf("Email = %s\n",addressBook -> contacts[i].email);
            num++;
            *i_value = i;
        }
    }
   *flag = num;
}

//Function defnition of create contact by name
int namecheck(char *chara)
{
                int i = 0, flag = 1;
                while(chara[i] != '\0')
                {
                    //Conditions for create a name for contact
                    if((chara[i] >= 'A') && (chara[i] <= 'Z') || (chara[i] >= 'a') && (chara[i] <= 'z')|| chara[i] == ' ')
                    {
                        flag = 1;
                    }
                    else{
                        flag = 0;
                        break;
                    }
                    i++;
                }
                if(flag == 1)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
    
}
//Function defnition of create contact by phone
int phonecheck(char *num,AddressBook *addressBook)
{
            int i = 0, flag = 1 , comp;
            while(num[i] != '\0')
            {
                    //Conditions for giving phone number to create contact
                    if ((num[i] >= '0')&& (num[i] <= '9')&&(strlen(num) == 10))
                    {
                        flag = 1;
                    }
                    else
                    {
                        flag = 0;
                        break;
                    }
                    i++;
                    for(int j = 0; j < addressBook->contactCount;j++)
                    {
                            comp = strcmp(num,addressBook -> contacts[j].phone);
                            if(comp == 0)
                            {
                                break;
                            }
                    }
                    if(comp == 0)
                    {
                        flag = 0;
                        break;
                    }
                    else
                    {
                        flag = 1;
                    }


            }
            if(flag == 1)
            {
                return 1;
            }
            else
            {
                return 0;
            }
}
//Function defnition for email to create contact
int mailcheck(char *Email,AddressBook *addressBook)
{
            int i = 0, flag =1, comp;
            int chara = strlen(Email);
            if ((strchr(Email,'@')))
            {


            //Conditions for create email in a contact
                while(Email[i] != '\0')
                {
                        if(Email[i] == '@')
                        {
                            //when these condition is include in mailid , it get invalid
                            if(Email [i-1] == '.' || Email[i+1] == '.' || Email [0]=='@')
                           {
                                flag = 0;
                                break;
                            }
                        }
                        i++;
                         for(int j = 0; j < addressBook->contactCount;j++)
                         {
                            comp = strcmp(Email,addressBook -> contacts[j].email);
                            if(comp == 0)
                            {
                                break;
                            }
                    }
                    if(comp == 0)
                    {
                        flag = 0;
                        break;
                    }
                    else
                    {
                        flag = 1;
                    }

  
                    //Condition for getting .com

                        if(Email[chara - 4] == '.' && Email[chara-3]=='c'&& Email[chara-2] =='o'&& Email[chara-1]=='m')
                        {
                            flag = 1;
                        }
                       
                        else
                        {
                            flag = 0;
                            break;

                        }
                }
            }
            else
            {
                flag = 0;
            }
            if(flag == 1)
            {
                return 1;
            }
            else
            {
                return 0;
            }
}


//Function declaration of create contact
void createContact(AddressBook *addressBook)
{
    //Declaring the variable
    char nameid[20];
    char num[10];
    char Email[30];
    int name = 0, phone = 0, mail = 0;
label1:
        printf("Enter your Name :\n");
        scanf(" %[^\n]",nameid);
        name = namecheck(nameid);
        //Condition for names if present 
    if(name ==1)
    {
        strcpy(addressBook->contacts[addressBook->contactCount].name,nameid);
    }
    else
    {
        //Condition if the name is not present
        printf("Invalid Name\n\n");
        goto label1;
    }
label2:
        printf("\nEnter a phone :\n");
        scanf("%s",num);
        phone = phonecheck(num,addressBook);
        //Condition for mobile number if present
        if(phone == 1)
        {
            strcpy(addressBook->contacts[addressBook->contactCount].phone,num);
        }
        else
        {
            //Condition for mobile number is not present
            printf("\nInvalid Phone Number\n\n");
            goto label2;

        }
label3:
        printf("\nEnter a Email:\n");
        scanf("%s",Email);
        mail = mailcheck(Email,addressBook);
        
        //Condition for email if present
        if(mail == 1)
        {
            strcpy(addressBook->contacts[addressBook->contactCount].email,Email);
        }
        else
        {
            //Condition for email is not present
            printf("\nInvalid Email\n\n");
            goto label3;
        }
        addressBook -> contactCount++ ;

  
	/* Define the logic to create a Contacts */
    
}

//Function declaration for search contact
void searchContact(AddressBook *addressBook)
{
    //Declaring the variable
    char searchName[100];
    char searchPhone[20];
    char searchEmail[100];


    int flag = 0;
    int matchname = 0;
    int matchphone = 0;
    int matchemail = 0;
    int option = 0;
    //Printing the options
label1:
    printf("\nEnter Option\n1.Name :\n2.Phone :\n3.Email :\n");
    
    scanf("%d",&option);
   //Cases for each option
    switch (option)
    {
        case 1:
label4:
            printf("\nEnter the name to search: ");
            scanf(" %[^\n]", searchName);

 
            for (int i = 0; i < addressBook->contactCount; i++)
            {
                if (strcasecmp(addressBook->contacts[i].name, searchName) == 0)
                 {
                        matchname++;
                 }
            }
            if(matchname == 0)
            {
                printf("\nInvalid name");
                goto label4;
            }
 
            //When multilple name found
            if (matchname > 1)
            {
                    for (int i = 0; i < addressBook->contactCount; i++)
                    {
                            if (strcasecmp(addressBook->contacts[i].name, searchName) == 0)
                                {
                                    printf("\nName: %s\n", addressBook->contacts[i].name);
                                    printf("Phone: %s\n", addressBook->contacts[i].phone);
                                    printf("Email: %s\n\n", addressBook->contacts[i].email);
                                }
                     }

                printf("\nMultiple names found.\n");
                goto label5;
            }
            //When there is only one name 
            else if (matchname == 1)
            {

                            for (int i = 0; i < addressBook->contactCount; i++)
                            {
                            if (strcasecmp(addressBook->contacts[i].name, searchName) == 0)
                                {
                                    printf("Name: %s\n", addressBook->contacts[i].name);
                                    printf("Phone: %s\n", addressBook->contacts[i].phone);
                                    printf("Email: %s\n", addressBook->contacts[i].email);
                                    flag = 1;
                                    break;
                                }
                            }
             }
            break;
        case 2:
label5:
            printf("\nEnter the Phone to search: ");
            scanf(" %[^\n]", searchPhone);

 
            for (int i = 0; i < addressBook->contactCount; i++)
            {
                if (strcasecmp(addressBook->contacts[i].phone, searchPhone) == 0)
                 {
                        matchphone++;
                 }
            }
            //When no number is found
            if(matchphone == 0)
            {
                printf("\nInvalid number");
                goto label5;
            }
            //When getting a matching number
            else if (matchphone == 1)
            {

                            for (int j = 0; j < addressBook->contactCount; j++)
                            {
                            if (strcasecmp(addressBook->contacts[j].phone, searchPhone) == 0)
                                {
                                    printf("Name: %s\n", addressBook->contacts[j].name);
                                    printf("Phone: %s\n", addressBook->contacts[j].phone);
                                    printf("Email: %s\n", addressBook->contacts[j].email);
                                    flag = 1;
                                    break;
                                }
                            }
             } 
             break;

        case 3:
label6:
            printf("\nEnter the Email to search: ");
            scanf(" %[^\n]", searchEmail);

 
            for (int i = 0; i < addressBook->contactCount; i++)
            {
                if (strcasecmp(addressBook->contacts[i].email, searchEmail) == 0)
                 {
                        matchemail++;
                 }
            }
            //When there is no corresponding email
            if(matchemail == 0)
            {
                printf("\nInvalid Email");
                goto label6;
            }
            //When one email is present
            else if (matchemail == 1)
            {

                            for (int k = 0; k < addressBook->contactCount; k++)
                            {
                            if (strcasecmp(addressBook->contacts[k].email, searchEmail) == 0)
                                {
                                    printf("Name: %s\n", addressBook->contacts[k].name);
                                    printf("Phone: %s\n", addressBook->contacts[k].phone);
                                    printf("Email: %s\n", addressBook->contacts[k].email);
                                    flag = 1;
                                    break;
                                }
                            }
             }
             break;
             //When we giving a invalid option
        default:
             
                 printf("\nInvalid Option\n\n");
                 goto label1;
                 break;
    
    }     


}
            
    /* Define the logic for search */

//Function Declaration for edit contact
void editContact(AddressBook *addressBook)
{
    //Declaring the variable
    int flag = 0, i_value = 0, option = 0, edit_cont = 0,res = 0;
    char Name[20];
    char Phone[10];
    char Email[30];
    int name,phone,email;
    
label5:
    //Printing the options that user need
    printf("Enter Option\n1. Name:\n2. Phone:\n3. Email:\n");
    scanf("%d", &option);

    //Cases to check each condition
    switch(option)
    {
        //Case for getting name
        case 1:
            res = 1;
label10:
            printf("\nEnter the name of the contact to edit: \n");
            scanf(" %[^\n]", Name);

            contactSearch1(Name, addressBook, &flag, &i_value);

            if (flag == 0)
            {
                printf("\nContact not found.....Try Again\n");
                goto label10;
            }

            if (flag > 1)
            {
                printf("\nMultiple contacts found.....Try with Phone number\n");
                goto label11;
            }

    
            break;
        //Case for getting phone number
        case 2:
            res = 1;
label11:
            printf("\nEnter the phone number of the contact to edit: \n");
            scanf("%s", Phone);

            contactSearch2(Phone, addressBook, &flag, &i_value);

            if (flag == 0)
            {
                printf("\nContact not found.....Try Again\n");
                goto label11;
            }

      
            break;
        //Case for getting email
        case 3:
            res = 1;
label12:
            printf("\nEnter the email of the contact to edit: \n");
            scanf("%s", Email);

            contactSearch3(Email, addressBook, &flag, &i_value);

            if (flag == 0)
            {
                printf("\nContact not found.....Try Again\n");
                goto label12;
            }

           
            break;
        default:
            printf("Invalid Option\n\n");
            res = 0;

    
    }
    if (res == 1)
    {

    //printing contact that the user want to edit
label02:
            printf("\nContact to edit \n");
            printf("\n1. Name\n2. Phone\n3. Email\n");
            scanf("%d", &edit_cont);

    //Case checking for edit the contact

    switch (edit_cont)
    {
        //Case for edit by name
        case 1:
label1:
        printf("\nEnter a new  Name :\n");
        scanf(" %[^\n]",Name);
        name = namecheck(Name);
        //Condition for names if present 
         if(name ==1)
         {
            strcpy(addressBook->contacts[i_value].name,Name);
         }
         else
         {
           //Condition if the name is not present
              printf("\nInvalid Name\n\n");
              goto label1;
         }
         break;
        //Case for edit by phone
        case 2:
label2:
            printf("\nEnter new phone of contact: ");
            scanf("%s",Phone);
            phone = phonecheck(Phone,addressBook);
            if(phone == 1)
            {
                strcpy(addressBook->contacts[i_value].phone,Phone);
            }
            else
            {
                printf("\nInvalid Phone\n\n");
                goto label2;
            }
            break;
            //Case for edit by email
        case 3:
label3:
            printf("\nEnter new email of contact: ");
            scanf("%s", addressBook->contacts[i_value].email);
            email = mailcheck(Email, addressBook);
            if(email == 1)
            {
                    strcpy(addressBook->contacts[i_value].email,Email);
             }
             else
             {
                 printf("\nInvalid Email\n\n");
                 goto label3;
             }

            break;
        default:
            printf("\nInvalid choice\n\n");
            goto label02;
            break;
    }

    printf("\n.....Contact has been edited successfully.....\n");
}


    else
    {
        goto label5;
    }
	/* Define the logic for Editcontact */
}

//Funtion Declaration for delete contact
void deleteContact(AddressBook *addressBook)
{

    int flag = 0, i_value = 0,option = 0;
    char Name[20];
    char Phone[10];
    char Email[30];
label01:
    printf("\nEnter Option\n1.Name :\n2.Phone :\n3.Email :\n");
    scanf("%d",&option);
     switch(option)
    {

        //Cases to deleting the contact by selecting options.
        //Case for delete by name
        case 1:
label7:
                printf("\nEnter the name of contact to delete : \n");
                scanf(" %[^\n]",Name);

                contactSearch1(Name , addressBook, &flag , &i_value);

                if(flag == 0)
                {
                printf("\nContact not found.....Try Again\n");
                goto label7;
                }
                if(flag > 1)
                {
                printf("\nMultiple contact found ..... Try with Phone number\n");
                goto label8;
                }
                for(int i = i_value ; i < addressBook -> contactCount; i++)
                {
                    strcpy(addressBook -> contacts[i].name, addressBook -> contacts[i+1].name);
                    strcpy(addressBook -> contacts[i].phone, addressBook -> contacts[i+1].phone);
                    strcpy(addressBook -> contacts[i].email, addressBook -> contacts[i+1].email);
                }
                printf("\n.....Contact as been deleted sucessfully.....\n");

                addressBook -> contactCount--;
                break;
               
        // Case for delete by phone number
        case 2:
label8:
                printf("\nEnter the phone number of contact to delete : \n");
                scanf("%s",Phone);

                contactSearch2(Phone , addressBook, &flag , &i_value);

                if(flag == 0)
                {
                        printf("\nContact not found.....Try Again\n");
                        goto label8;
                }
                printf("print-->%d\n",i_value);
                for(int i = i_value ; i < addressBook -> contactCount; i++)
                {
                        strcpy(addressBook -> contacts[i].name, addressBook -> contacts[i+1].name);
                        strcpy(addressBook -> contacts[i].phone, addressBook -> contacts[i+1].phone);
                        strcpy(addressBook -> contacts[i].email, addressBook -> contacts[i+1].email);
                }
                printf("\n.....Contact as been deleted sucessfully.....\n");

                addressBook -> contactCount--;
                break;

        //Case for delete by email
        case 3:
label9:
                printf("\nEnter the Email of contact to delete : \n");
                scanf("%s",Email);

                contactSearch3(Email , addressBook, &flag , &i_value);

                if(flag == 0)
                {
                        printf("\nContact not found.....Try Again\n");
                        goto label9;
                }
                for(int i = i_value ; i < addressBook -> contactCount; i++)
                {
                        strcpy(addressBook -> contacts[i].name, addressBook -> contacts[i+1].name);
                        strcpy(addressBook -> contacts[i].phone, addressBook -> contacts[i+1].phone);
                        strcpy(addressBook -> contacts[i].email, addressBook -> contacts[i+1].email);
                }
                printf("\n.....Contact as been deleted sucessfully.....\n");

                addressBook -> contactCount--;
                break;
        default:
                printf("Invalid Option\n\n");
                goto label01;
                break;
    }
    
}

