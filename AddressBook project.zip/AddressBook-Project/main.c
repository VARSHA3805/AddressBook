/* Documentation
Name : VARSHA.E
Date : 19/10/2024
DES  : Addressbook project
*/
#include <stdio.h>
#include "contact.h"
#include "file.h"
int main() {
    int choice;
    AddressBook addressBook;
    initialize(&addressBook); // Initialize the address book
    //Function call for load the contacts from file
    loadContactsFromFile(&addressBook);
    
    //For getting the menu at first
    do {
        printf("\nAddress Book Menu:\n");
        printf("1. Create contact\n");
        printf("2. Search contact\n");
        printf("3. Edit contact\n");
        printf("4. Delete contact\n");
        printf("5. List all contacts\n");
    	printf("6. Save contacts\n");		
        printf("7. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        
        switch (choice) {
            case 1:
                //Function call for create contact
                createContact(&addressBook);
                break;
                
            case 2:
                //Function call for search contact
                searchContact(&addressBook);
                break;
            case 3:
                //Function call for edit contact
                editContact(&addressBook);
                break;
            case 4:
                //Function call for delete contact
                deleteContact(&addressBook);
                break;
            case 5:          
                //Function call for list contact
                listContacts(&addressBook);
                break;
            case 6:
                //Function call for save the contact
                printf("...Saved Successfully...\n");
                saveContactsToFile(&addressBook);
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }

    }
   //If there is other than 1-7  
    while (choice != 7);
    
       return 0;
}
